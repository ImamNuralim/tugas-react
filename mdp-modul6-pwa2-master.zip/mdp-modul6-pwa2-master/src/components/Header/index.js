// index.js
import React from "react";
import "./index.css";

export default function index() {
    return (
        <header>
            <h3>Kelompok xx</h3>
            <p>Modul 6 - PWA 2</p>
        </header>
    );
}